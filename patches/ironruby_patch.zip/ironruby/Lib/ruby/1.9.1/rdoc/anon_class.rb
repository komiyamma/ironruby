require 'rdoc/class_module'

##
# An anonymous class like:
#
#   c = Class.new do end

class RDoc::AnonClass < RDoc::ClassModule
end

